package main

import (
	"strconv"
	"strings"

	"github.com/gofiber/fiber/v2"
)

// Fungsi-fungsi pembungkus respons HTTP
func ok(c *fiber.Ctx, message string, data any) error {
	return c.Status(fiber.StatusOK).JSON(WebResponse{Success: true, Message: message, Data: data})
}

func okList(c *fiber.Ctx, message string, data any, meta *Meta) error {
	return c.Status(fiber.StatusOK).JSON(WebResponse{Success: true, Message: message, Data: data, Meta: meta})
}

func created(c *fiber.Ctx, message string, data any, location string) error {
	c.Set("Location", location) // Memberi tahu klien letak sumber daya baru
	return c.Status(fiber.StatusCreated).JSON(WebResponse{Success: true, Message: message, Data: data})
}

func noContent(c *fiber.Ctx) error {
	return c.SendStatus(fiber.StatusNoContent) // 204
}

func fail(c *fiber.Ctx, status int, message string) error {
	return c.Status(status).JSON(WebResponse{Success: false, Message: message})
}

func failValidation(c *fiber.Ctx, errs map[string]string) error {
	return c.Status(fiber.StatusUnprocessableEntity).JSON(WebResponse{
		Success: false, Message: "validasi gagal", Errors: errs,
	})
}

// Daftar putih untuk mencegah SQL/Memory Injection (meski saat ini masih di memori)
var allowedSort = map[string]bool{"id": true, "name": true, "grade": true}

func parseListQuery(c *fiber.Ctx) ListQuery {
	q := ListQuery{
		Page:   c.QueryInt("page", 1),
		Limit:  c.QueryInt("limit", 10),
		Search: strings.TrimSpace(c.Query("search")),
		Sort:   c.Query("sort", "id"),
		Order:  strings.ToLower(c.Query("order", "asc")),
	}

	if q.Page < 1 {
		q.Page = 1
	}
	if q.Limit < 1 {
		q.Limit = 10
	}
	// Batas atas wajib ada agar klien tidak menarik jutaan data dan mematikan server
	if q.Limit > 50 { 
		q.Limit = 50
	}
	if !allowedSort[q.Sort] {
		q.Sort = "id"
	}
	if q.Order != "desc" {
		q.Order = "asc"
	}

	if raw := c.Query("is_active"); raw != "" {
		if v, err := strconv.ParseBool(raw); err == nil {
			q.IsActive = &v
		}
	}
	return q
}